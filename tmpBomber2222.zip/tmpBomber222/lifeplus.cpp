#include "lifeplus.h"

LifePlus::LifePlus() : Gift()
{

}
void LifePlus::addLife(Player &player)
{
player.setLife(player.getLife()+1);
}
