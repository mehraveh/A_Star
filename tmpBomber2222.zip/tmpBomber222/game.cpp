#include "game.h"
#include  <iostream>
#include <string>
#include <fstream>
#include <ctime>
using namespace std;
Game::Game()
{
// srand(time(0));
}
void Game::Board_Cout( Board &board)
{
	for (int i = 0; i < 17; i++)
	{
		for (int j = 0; j < 17; j++)
		{
			cout<<board.game_board[i][j]<<" ";
		}
		cout<<endl;
	}
}
Key* Game::setKeys(GraphicBomber &graphic ,Key &key ,Player &player)
{
	key.right=graphic.rightKeyPressed();
	key.left=graphic.leftKeyPressed();
	key.up=graphic.upKeyPressed();
	key.down = graphic.downKeyPressed();
	if(key.right || key.left || key.up || key.down)
	{
	cout<<"x="<<player.getX()<<endl;
    cout<<"y="<<player.getY()<<endl;}
    
	return &key;
}
Gift ** Game::locateGift( Board &board)
{
	bool b;
	int t1 ,t2;
	bool**giftLoc;
		giftLoc = new bool *[17];
	for (int i = 0; i <17; i++)
	{
		
		giftLoc[i] = new bool [17];
	}
	for( int i = 0 ; i < 17 ;i++)
		for( int j = 0 ; j < 17 ;j++)
			giftLoc[i][j]=false;
	Gift ** tmp = new Gift* [10];
   srand(time(0));
	   for ( int  i = 0 ; i < 10 ; i++ )
	   {
	   	b = rand()%2;
        if(b)
        {
        	
        	tmp[i] = new LifePlus();
        	cout<<"l"<<endl;
        }
        else
        {
        
        	tmp[i] = new BombPlus();
        	cout<<"b"<<endl;
        }
	 
	do{
		
		t1=rand()%17;
		t2=rand()%17;
		tmp[i]->setX(rand()%17);
		tmp[i]->setY(rand()%17);
		
     

  }	while(board.game_board[tmp[i]->getX()][tmp[i]->getY()]!='e'  ||giftLoc[tmp[i]->getX()][tmp[i]->getY()]==1);
cout<<tmp[i]->getX()<<" "<<tmp[i]->getY()<<endl;
giftLoc[tmp[i]->getX()][tmp[i]->getY()]=1;
}
    return tmp;
}
void Game::run(GraphicBomber &graphic, Key &key , Player &player , Board &board ,Bomb &bomb ,Gift**gift)
{
	
	
	
    player.moveControl(*(setKeys(graphic ,key ,player)),board);
    bomb.bombIsLocated(key ,player,graphic.bKeyPressed());
    bomb.boardUpdater(board , player , player );
  
    

    
    
}

