#include "GraphicBomber.h"
using namespace sf;
	GraphicBomber::GraphicBomber()
	{
        window = new RenderWindow (VideoMode(714,714), "bomber man !");
		rectangle = new RectangleShape* [17];
		for( int i = 0 ; i < 17 ;i++)
		{
			rectangle[i] = new RectangleShape[17];
		}

	}
	
	/*void GraphicBomber::LoadTexture( Texture &texture , string filename)
		{
			 texture.loadFromFile(filename.c_str());
		}*/
		   void GraphicBomber::LoadTexture1( Texture &texture )
		{
			 texture.loadFromFile("noWall2.jpg");
		}
		void GraphicBomber::LoadTexture2( Texture &texture )
		{
			 texture.loadFromFile("noWall2.jpg");
		}
		void GraphicBomber::LoadTexture3( Texture &texture )
		{
			 texture.loadFromFile("brick.jpg");
		}
		void GraphicBomber::LoadTexture4( Texture &texture )
		{
			 texture.loadFromFile("exAbleWall.jpg");
		}
	void GraphicBomber::load()//----------------------load pics
    {
    	LoadTexture3(brick );
    	LoadTexture4(exAbleWall );
    	LoadTexture1(noWall1 );
    	LoadTexture2(noWall2 );
    }
	 void GraphicBomber::clearScreen(){
            window->clear();

        }

	 void GraphicBomber::closeWindow()
         {
             window->close();
             
       }
     bool GraphicBomber::isWindowOpen()
     {
             return window->isOpen();
      }
      void GraphicBomber::display(){
       window->display();

  }

    void GraphicBomber::drawRect(RectangleShape **r,int i , int j){
     window->draw(r[i][j]);
     }
     void GraphicBomber::drawCir(CircleShape &circle){
     window->draw(circle);
     }
	  bool GraphicBomber::rightKeyPressed(){
	     if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
	    {  
	        return true;}
	     else 
	        return false;
	}

	bool GraphicBomber::upKeyPressed(){
	     if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
	          return true;
	       else 
	          return false;
	}
	bool GraphicBomber::downKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
	         return true;
	  else 
	         return false;
	}
	bool GraphicBomber::bKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::B))
	        {
	         return true;}
	  else 
	         return false;
	}
		bool GraphicBomber::leftKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
	         {
	         	
	         	return true;
	         }
	  else 
	         return false;
	}
	    void GraphicBomber::setTextureCBrike(RectangleShape ** rectangle,int i , int j)
  		{
   			 rectangle[i][j].setTexture(&brick);
   		}
   		 void GraphicBomber::setTextureCExAbleWall(RectangleShape ** rectangle,int i , int j)
  		{
   			 rectangle[i][j].setTexture(&exAbleWall);
   		}
   		 void GraphicBomber::setTextureCNoWall1(RectangleShape ** rectangle,int i , int j)
  		{
   			 rectangle[i][j].setTexture(&noWall1);
   		}
   		 void GraphicBomber::setTextureCNoWall2(RectangleShape ** rectangle,int i , int j)
  		{
   			 rectangle[i][j].setTexture(&noWall2);
   		}

   		void GraphicBomber::setBoard(Board &board)
	{
		for( int j=0 ; j<17 ; j++)
		{
			for( int i=0 ;i<17 ; i++)
					{
						if(board.game_board[i][j]=='n')
						{
							setTextureCNoWall1(rectangle ,i ,j );
						}
						if(board.game_board[i][j]=='N')
						{
							setTextureCNoWall2( rectangle , i , j);
						}
						if(board.game_board[i][j]=='e')
						{
							setTextureCExAbleWall( rectangle , i , j);
						}
						if(board.game_board[i][j]=='b')
						{
							setTextureCBrike( rectangle , i , j);
						}
					}
		}
	}
	 void GraphicBomber::setPositionR( RectangleShape **r,int x,int y,int i ,int j)
  {
    r[i][j].setPosition( x , y );
  }
  void GraphicBomber::setPositionC( CircleShape &c,int x,int y)
  {  c.setPosition( x , y );
  }
   
    void GraphicBomber::rectSetsize(int i ,int j,int x,int y)
  {
        rectangle[i][j].setSize(sf::Vector2f(x, y));
  }
  void GraphicBomber::circleSetSize( CircleShape &c, int r)
  {
     c.setRadius(r);
  }
	void GraphicBomber::show(Board &board ,Player &player ,Bomb &bomb)
	{
		load();
		clearScreen();
		setBoard(board);
		for (int i = 0; i < 17; i++)
		{
			for (int j = 0; j < 17; j++)
			{
				rectSetsize( i, j ,42,42);
				setPositionC(circle ,player.getX()*42,player.getY()*42);
				setPositionR(rectangle ,i*42,j*42 , i, j);
				drawRect(rectangle , i, j);
				
			}
			if(bomb.bombLocated)
			{
				circleSetSize( bombC , 10);
				setPositionC(bombC ,bomb.getX()*42,bomb.getY()*42);
		         drawCir(bombC);
			}
		}
		circleSetSize( circle , 21);
		drawCir(circle);
		display();
	}

