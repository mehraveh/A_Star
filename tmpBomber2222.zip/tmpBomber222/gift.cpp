#include "gift.h"

	Gift::Gift()
	{

	}

    void Gift::setX( int x)
    {
    	this-> x=x;
    }
    int Gift::getX()
    {
    	return x;
    }
    void Gift::setY( int y)
    {
    	this-> y = y;
    }
    int Gift::getY()
    {
    	return y;
    }
    void Gift::addLife(Player &player)
	{
	
	}
	 void Gift::rangAdder(Bomb &bomb)
    {
    	
    }

