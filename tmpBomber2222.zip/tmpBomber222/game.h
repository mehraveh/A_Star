#ifndef GAME_H
#define GAME_H
#include <string>
#include <fstream>
#include "player.h"
#include "GraphicBomber.h"
#include "bomb.h"
#include "gift.h"
#include "bombplus.h"
#include "lifeplus.h"
class Game
{
public:
    Game();
   void  Board_Cout( Board &board);
   Key* setKeys(GraphicBomber &graphic ,Key &key ,Player &player);
   Gift**locateGift(Board &board);
   void run(GraphicBomber &graphic ,Key &key , Player &player ,  Board &board ,Bomb &bomb ,Gift**gift);
};

#endif // GAME_H
