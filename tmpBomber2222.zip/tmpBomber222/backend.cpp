#include "backend.h"
#include <ctime>

BackEnd::BackEnd()
{
	gift = new Gift*[10];

}
void BackEnd::run()
{ 
	board.setWallType("map1.txt");
	game.Board_Cout(board);
	//srand(time(0));
	gift= game.locateGift(board);
	while(true)
	{
	game.run(graphic, key ,player , board ,bomb , gift);
	graphic.show(board ,player,bomb);
     }
}
