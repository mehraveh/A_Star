#include "player.h"
Player::Player()
{
 x=3;
 y=7;
 life=3;
}
void  Player::moveControl(Key &key , Board &board )
{
	if(key.up && (board.game_board[x][y-1]=='n'|| board. game_board[x][y-1]=='N'))
		{y=y-(1);
        }

	if(key.down && (board.game_board[x][y+1]=='n'|| board. game_board[x][y+1]=='N'))
		{y=y+(1);
     }

	if(key.right && (board.game_board[x+1][y]=='n'|| board. game_board[x+1][y]=='N'))
		{x=x+(1);
       }

	if(key.left && (board.game_board[x-1][y]=='n'|| board. game_board[x-1][y]=='N'))
		{x=x-(1);
      }
}
void Player::setLife( int life )
{
	this->life = life;
}
   int Player::getLife()
{
	return life;
}
  void Player::setX( int x)
    {
    	this-> x=x;
    }
    int Player::getX()
    {
    	return x;
    }
    void Player::setY( int y)
    {
    	this-> y = y;
    }
    int Player::getY()
    {
    	return y;
    }

