    #include "bomb.h"
  
Bomb::Bomb()
{
	upRang=1;
	downRang=1;
	leftRang=1;
	rightRang=1;
    x = 1;
    y = 1;
    bombLocated = false;
    timeE = 0 ;
    //tmp = 0 ;
    //tmp2 = 0;
}
    void Bomb::setX( int x)
    {
    	this-> x=x;
    }
    int Bomb::getX()
    {
    	return x;
    }
    void Bomb::setY( int y)
    {
    	this-> y = y;
    }
    int Bomb::getY()
    {
    	return y;
    }
    void Bomb::setLeftRang( int leftRang)
    {
    	this->leftRang = leftRang;
    }
    int Bomb::getLeftRang()
    {
    	return leftRang;
    }
    void Bomb::setRightRang( int rightRang)
    {
    	this-> rightRang = rightRang;
    }
    int Bomb::getRightRang()
    {
    	return rightRang;
    }
    void Bomb::setUpRang( int upRang)
    {
    	this -> upRang = upRang;
    }
    int Bomb::getUpRang()
    {
    	return upRang;
    }
    void Bomb::setDownRang( int downRang)
    {
    	this -> downRang = downRang;
    }
    int Bomb::getDownRang()
    {
    	 return downRang; 
    }
    void Bomb::setEXTime( int exTime)
    {
    	this -> exTime = exTime;
    }
    int Bomb::getExTime()
    {
    	return exTime;
    }
    void Bomb::bombIsLocated( Key &key  ,Player &player ,bool bo)
    {
        key.b= bo;
       // int * tmp = new int [2];
        if(key.b)
        {
           // bombLocated=true;
            cout<<"bomb Loacted"<<endl;
            this->setX(player.getX());
            this->setY(player.getY());
            //tmp[0]=this->getX();
           // tmp[1]=this->getY();
            cout<<"bomb x = "<<this->getX()<<endl;
            cout<<"bomb y = "<<this->getY()<<endl;
           // bombLocated=false;
            cout<<"bomb released"<<endl;
            key.b = false;  
            bombLocated = true;    //return tmp;
        }
        
        


    }
   bool Bomb::bombIsExploded()
   {


    if(bombLocated)
    {
     
    if(timeE == 0)
 {
     tmp = time(0);
 }
  timeE++;
  tmp2 = time(0);
  cout<<"locateTime:"<< tmp<< endl;
  cout<<"curTime:"<<tmp2<<endl;
  if(tmp2 - tmp> 3)
  {
        bombLocated = false;
        timeE = 0;
        return true;
  }
  else 
         {
            cout<<"n ex"<<endl;
             return  false;
         }


}
else 
return false;

}

    void Bomb::boardUpdater(Board &board , Player &p1, Player &p2)
    {
        if(bombIsExploded())
        {  
           
                if (board.game_board[x + 1][y]=='e')
                       board.game_board[x + 1][y]='n';
            for (int i = 1; i < rightRang ||i == rightRang ; i++)
            { 

               if (p1.getX() == x + i && p1.getY() == y)
                   p1.setLife(p1.getLife()-1);
                      
                  

                if (p2.getX() == x + i && p2.getY() == y)
                    p2.setLife(p2.getLife()-1);

            }

                if (board.game_board[x - 1][y]=='e')
                    board.game_board[x - 1][y]='n';
            for (int i = 1; i <leftRang ||i == leftRang ; i++)
            {
				
                     
                if (p1.getX() == x - i && p1.getY() == y)
                    p1.setLife(p1.getLife()-1);


                if (p2.getX() == x - i && p2.getY() == y)
                   p2.setLife(p2.getLife()-1);

            }

                if (board.game_board[x][y - 1]=='e')
                    board.game_board[x][y - 1]='n';
            for (int i = 1; i < upRang || i == upRang ; i++)
            {
			


                if (p1.getX() == x && p1.getY() == y - i)
                    p1.setLife(p1.getLife()-1);


                if (p2.getX() == x && p2.getY() == y - i)
                   p2.setLife(p2.getLife()-1);
    
          }
                if (board.game_board[x][y + 1]=='e')
                    board.game_board[x][y + 1]='n';

            for (int i = 1; i < downRang ||i == downRang ; i++)
            {
		

                if (p1.getX() == x  && p1.getY() == y + i)
                   p1.setLife(p1.getLife()-1);


                if (p2.getX() == x && p2.getY() == y + i)
                    p2.setLife(p2.getLife()-1);
              
            }
             if (p1.getX() == x  && p1.getY() == y )
                   p1.setLife(p1.getLife()-1);


             if (p2.getX() == x && p2.getY() == y )
                    p2.setLife(p2.getLife()-1);
            cout<<p1.getLife()<<endl;
            cout<<p2.getLife()<<endl;

        }
        
    }

