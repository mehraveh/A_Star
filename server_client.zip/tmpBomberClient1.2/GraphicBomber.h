#ifndef GRAPHICBOMBER_H
#define GRAPHICBOMBER_H
#include <SFML/Graphics.hpp>
#include <stdlib.h>
#include <time.h>
#include <sstream>
#include <string>
#include <SFML/Window/Mouse.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include "gift.h"
#include "lifeplus.h"
#include "bombplus.h"
#include "board.h"
#include "player.h"
#include "bomb.h"
using namespace std;

using namespace sf;

class GraphicBomber
{
private:
	  RenderWindow* window;
      RectangleShape** rectangle;
      CircleShape circle;
      CircleShape bombC;
      Texture brick;
	  Texture exAbleWall;
	  Texture noWall1;
	  Texture noWall2;
	  Texture bomb_plus;
	  Texture life_plus;
	  Texture playerDown;
	  RectangleShape gift_lp_rect;
	  RectangleShape gift_bp_rect;
	  RectangleShape player_down;
public:
	GraphicBomber();
	void LoadTexture1( Texture &texture );
	void LoadTexture2( Texture &texture );
	void LoadTexture3( Texture &texture );
	void LoadTexture4( Texture &texture );
	void LoadTexture5( Texture &texture );
	void LoadTexture6( Texture &texture );
	void LoadTexture7( Texture &texture );
	void load();
	bool rightKeyPressed();
	bool upKeyPressed();
	bool downKeyPressed();
	bool bKeyPressed();
	bool leftKeyPressed();
	bool mKeyPressed();
	bool sKeyPressed();
	bool wKeyPressed();
	bool aKeyPressed();
	bool dKeyPressed();
	void closeWindow();
	bool isWindowOpen();
	void clearScreen();
	void setTextureCBrike( RectangleShape** rectangle,int i , int j);
	void setTextureCExAbleWall(RectangleShape ** rectangle,int i , int j);
	void setTextureCNoWall1(RectangleShape ** rectangle,int i , int j);
    void setTextureCNoWall2(RectangleShape** rectangle,int i , int j);
    void setTextureGiftBP(RectangleShape &r);
    void setTextureGiftLP(RectangleShape &r);
    void setTexturePlayerDown(RectangleShape &r);
	void setBoard(Board &board);
	void drawRect(RectangleShape **r,int i , int j);
	void display();
	void drawCir(CircleShape &circle);
	void drawSingleRect(RectangleShape &r);
	void setPositionR( RectangleShape **r,int x,int y,int i ,int j);
	 void setPositionC( CircleShape &c,int x,int y);
	 	void setPositionSR(RectangleShape &r, int x, int y);
	 void rectSetsize(int i ,int j,int x,int y);
	 void circleSetSize( CircleShape &c ,int r);
	 void singleRectSetSize(RectangleShape &r, int x, int y);
	 void showGift(Gift ** gift ,Board &board);
	void show(Board &board ,Player &player1 ,Bomb &bomb1 ,Player &player2 ,Bomb &bomb2 ,Gift ** gift);
	};
#endif // GRAPHICBOMBER_H
