#include "backend.h"
#include <ctime>

BackEnd::BackEnd()
{
	gift = new Gift*[10];

}
void BackEnd::run()
{
	
    TcpSocket *socket = new sf::TcpSocket();
    socket->connect("127.0.0.1", 55001);
	board.setWallType("map1.txt");
	game.Board_Cout(board);
	gift= game.locateGift(board);
	//int counter = 0;
	while(game.isAlive(player1) && game.isAlive(player2))
	{
		// cout<< "cycle: " << (counter++) <<endl;
	     game.run(graphic, key1 ,key2 ,player1 ,player2 , board ,bomb1 ,bomb2 , gift , socket );
	     graphic.show(board , player1 , bomb1 ,player2 , bomb2, gift);	
	   
}
cout<<"finished"<<endl;
}
