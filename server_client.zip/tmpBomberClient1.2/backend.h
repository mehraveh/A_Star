#ifndef BACKEND_H
#define BACKEND_H
#include "game.h"
#include <cstdlib>
#include <SFML/Network.hpp>
using namespace sf;
class BackEnd
{private:
	Game game;
	Player player1;
	Board board;
	Key key1;
	Bomb  bomb1;
	GraphicBomber graphic;
	Gift**gift;
	Player player2;
	Key key2;
	Bomb  bomb2;
public:
	
    BackEnd();
    void run();
};

#endif // BACKEND_H
