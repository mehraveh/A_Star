#ifndef GAME_H
#define GAME_H
#include <iostream>
#include <string>
#include <fstream>
#include "player.h"
#include "GraphicBomber.h"
#include "bomb.h"
#include "gift.h"
#include "bombplus.h"
#include "lifeplus.h"
#include <SFML/Network.hpp>
using namespace std;
class Game
{
public:
    Game();
    std::size_t received ;
    bool bmb ;
  string message;
   void  Board_Cout( Board &board);
   Key* setKeys1(GraphicBomber &graphic ,Key &key ,Player &player);
   Key* setKeys2(GraphicBomber &graphic ,Key &key,Player &player,char* buffer);
   Gift**locateGift(Board &board);
   bool isAlive(Player &player);
   void giftApply(Player &player ,Gift ** gift , Bomb &bomb);
    void  sendKey(Key &key);
    string sendBomb(Key &key);
   void run(GraphicBomber &graphic, Key &key1,Key &key2 , Player &player1 ,Player &player2 , Board &board ,Bomb &bomb1 ,Bomb &bomb2 ,Gift**gift , TcpSocket *socket );
};

#endif // GAME_H
