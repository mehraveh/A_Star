#ifndef PLAYER_H
#define PLAYER_H
#include "board.h"
#include "key.h"
#include <iostream>
using namespace std;
class Player
{
private:

	int life;
public:
	int x;
	int y;
   Player();
   void moveControl(Key &key , Board &board );
   void setLife( int life );
   int getLife();
   void setX( int x);
   int getX();
   void setY( int y);
   int getY();

};

#endif // PLAYER_H
