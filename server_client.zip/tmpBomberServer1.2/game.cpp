#include "game.h"
#include  <iostream>
#include <string>
#include <fstream>
#include <ctime>
using namespace std;
Game::Game()
{
	received = 0;
	bmb = 0 ;
	string message;

}
void Game::Board_Cout( Board &board)
{
	for (int i = 0; i < 17; i++)
	{
		for (int j = 0; j < 17; j++)
		{
			cout<<board.game_board[i][j]<<" ";
		}
		cout<<endl;
	}
}
Key* Game::setKeys1(GraphicBomber &graphic ,Key &key ,Player &player)
{
	key.right=graphic.rightKeyPressed();
	key.left=graphic.leftKeyPressed();
	key.up=graphic.upKeyPressed();
	key.down = graphic.downKeyPressed();
    
	return &key;
}
Key* Game::setKeys2(GraphicBomber &graphic ,Key &key ,Player &player ,char* buffer)
{
	if(*buffer == 'r')
       {cout<<"rKp"<<endl;
       	key.right=true;
        key.left=false;
		key.up = false;
		key.down = false;}
       // else
        //key.right=false;
    else if(*buffer == 'l')
	   {cout << "lKp"<<endl;
	   	key.left=true;
        key.right=false;
        key.up = false;
		key.down = false;
	   }
	    //else
        //key.left=false;
	else if(*buffer == 'u')
		{cout << "uKp"<<endl;
			key.up = true;
		key.right=false;
		key.left=false;
		key.down = false ;}
		 //else
        //key.up=false;
	 else if(*buffer == 'd')
	   {cout << "d"<<endl;
	   	key.down = true ;
	   	key.right=false;
		key.left=false;
		key.up = false;}
	   // else
        //key.down=false;
        else 
        {cout << "nKp"<<endl;
        key.right=false;
		key.left=false;
		key.up = false;
		key.down = false ;
			
			}
    
	return &key;
}
void Game::sendKey(Key &key)
 {
 	
    	if (key.up)
	{


		cout<<" sent u"<<endl;
		message = 'u';
		//cout<<"u"<<endl;
		//y=-42;
	}
	else if (key.down)
	{
		cout<<" sent d"<<endl;
		message = 'd';
		//cout<<"d"<<endl;
		//y=+42;
	}
	else if (key.right)
	{cout<<" sent r"<<endl;
		//cout<<"r"<<endl;
		message = 'r';
		//x=+42;
	}
	else if (key.left)
	{cout<<" sent l"<<endl;
		//cout<<"l"<<endl;
		message = 'l';
		//x-=42;
	}
	else 
		message = 'n';
	
 }
  string Game::sendBomb(Key &key)
  {
      if (key.b)
	{
		message = 'b';
	
	}
	
	 return message ;

  }
Gift ** Game::locateGift( Board &board)
{
	bool b;
	int t1 ,t2;
	bool**giftLoc;
		giftLoc = new bool *[17];
	for (int i = 0; i <17; i++)
	{
		
		giftLoc[i] = new bool [17];
	}
	for( int i = 0 ; i < 17 ;i++)
		for( int j = 0 ; j < 17 ;j++)
			giftLoc[i][j]=false;
	Gift ** tmp = new Gift* [10];
   srand(time(0));
	   for ( int  i = 0 ; i < 10 ; i++ )
	   {
	   	b = rand()%2;
        if(b)
        {
        	
        	tmp[i] = new LifePlus();
        	cout<<"l"<<endl;
        }
        else
        {
        
        	tmp[i] = new BombPlus();
        	cout<<"b"<<endl;
        }
	 
	do{
		
		t1=rand()%17;
		t2=rand()%17;
		tmp[i]->setX(rand()%17);
		tmp[i]->setY(rand()%17);
		
     

  }	while(board.game_board[tmp[i]->getX()][tmp[i]->getY()]!='e'  ||giftLoc[tmp[i]->getX()][tmp[i]->getY()]==1);
cout<<tmp[i]->getX()<<" "<<tmp[i]->getY()<<endl;
giftLoc[tmp[i]->getX()][tmp[i]->getY()]=1;
}
    return tmp;
}
void Game::giftApply(Player &player ,Gift ** gift , Bomb &bomb )
{
	for(int i = 0 ;i<10 ;i++)
	{
		if(player.getX() == gift[i]->getX() && player.getY() == gift[i]->getY() && gift[i]->isSeen == false)
			{
				gift[i]->rangAdder(bomb);
				gift[i]->addLife(player);
				gift[i]->isSeen = true;
					
  	    }
		
    }
}
bool Game::isAlive(Player &player)
{
	if(player.getLife() <  0 || player.getLife() == 0)
	    return false;
	else
	{
		cout<<player.getLife()<<endl;
	    return true;}
	
}
void Game::receiveFunc(char* buffer ,TcpSocket* socket)
{
	if(buffer != NULL )
	{
		socket->receive(buffer, sizeof(buffer), received);
	}
	delete [] buffer;
}
void Game::run(GraphicBomber &graphic, Key &key1, Key &key2 , Player &player1 ,Player &player2 , Board &board ,Bomb &bomb1 ,Bomb &bomb2 ,Gift**gift  ,TcpSocket* socket  )
{     char * buffer = new char[1];
    //Thread* thread = new Thread(&receiveFunc , socket);
	//thread->launch();
	socket->receive(buffer, sizeof(buffer), received);
	player2.moveControl(*(setKeys2(graphic ,key2 ,player2 , buffer )),board);
	key1 = *(setKeys1(graphic ,key1 ,player1));
    player1.moveControl(key1,board);
    sendKey(key1);
    socket->send(message.c_str(),message.size() + 1);
    key1.down = false ;
	key1.right=false;
    key1.left=false;
    key1.up = false;
    /*
        if(buffer[0] == 'u')
		{player2.y-=1;
	    key2.right=false;
		key2.left=false;
		key2.up = true;
		key2.down = false ;}
		else if(buffer[0] == 'd')
		{player2.y+=1;
		 key2.right=false;
		key2.left=false;
		key2.up = false;
		key2.down = true ;}
		else if(buffer[0] == 'l')
		{player2.x-=1;
		 key2.right=false;
		key2.left=true;
		key2.up = false;
		key2.down = false ;}
		else if(buffer[0] == 'r')
		{player2.x+=1;
		key2.right=true;
		key2.left=false;
		key2.up = false;
		key2.down = false ;}
		else 
		{player2.x+=0;
		key2.right=false;
		key2.left=false;
		key2.up = false;
		key2.down = false ;}
    key1.right=graphic.rightKeyPressed();
	key1.left=graphic.leftKeyPressed();
	key1.up=graphic.upKeyPressed();
	key1.down = graphic.downKeyPressed();
	if(key1.up && (board.game_board[player1.x][player1.y-1]=='n'|| board. game_board[player1.x][player1.y-1]=='N'))
		{player1.y=player1.y-(1);
		message = 'u';
        key1.up=false;}
	if(key1.down && (board.game_board[player1.x][player1.y+1]=='n'|| board. game_board[player1.x][player1.y+1]=='N'))
		{player1.y=player1.y+(1);
		message = 'd';
        key1.down=false;}

	if( key1.right && (board.game_board[player1.x+1][player1.y]=='n'|| board. game_board[player1.x+1][player1.y]=='N'))
		{player1.x=player1.x+(1);
		message = 'r';
        key1.right=false;}

	if(key1.left && (board.game_board[player1.x-1][player1.y]=='n'|| board. game_board[player1.x-1][player1.y]=='N'))
		{player1.x=player1.x-(1);
		message = 'l';
        key1.left=false;}
    */
    bomb1.bombIsLocated(key1 ,player1,graphic.bKeyPressed());
    bomb1.boardUpdater(board ,player1 , player2 );
    bomb2.bombIsLocated(key2,player2,graphic.mKeyPressed());
    bomb2.boardUpdater(board , player1 , player2 );
    giftApply(player1 , gift ,bomb1);
    giftApply(player2 , gift ,bomb2);
    //delete [] &thread;
    
}

