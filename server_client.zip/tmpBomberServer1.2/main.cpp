#include "backend.h"
#include <string>
#include <fstream>
#include <iostream>
using namespace std;

int main()
{
	//srand(time(0));
	BackEnd backend;
	backend.run();

}
