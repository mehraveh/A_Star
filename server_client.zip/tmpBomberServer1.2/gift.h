#ifndef GIFT_H
#define GIFT_H
#include "board.h"
#include "player.h"
#include "bomb.h"
//#include "lifeplus.h"
//#include "bombplus.h"
#include <cstdlib>
#include <ctime>

class Gift
{
protected:
	int x;
	int y;
public:
bool isSeen;
    Gift();
     //Gift* randXY(Board &board);
     void setX( int x);
    int getX();
    void setY( int y);
    int getY();
    virtual void rangAdder(Bomb &bomb);
    virtual void addLife(Player &player);
    virtual char getType();
    
 
};

#endif // GIFT_H
