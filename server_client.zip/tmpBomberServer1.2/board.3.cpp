#include "board.h"
#include <fstream>
#include <string>
#include <iostream>
using namespace std;
Board::Board()
{
	game_board = new char *[17];
	for (int i = 0; i <17; i++)
	{
		
		game_board[i] = new char [17];
	}

}
	void Board::setWallType( string filename)
	{
		ifstream map( filename.c_str());
		for( int i=0 ; i<17 ; i++)
		{
			for(int j=0 ;j<17 ;j++)
			{
				map >> game_board[i][j];
			}
		}
	}
