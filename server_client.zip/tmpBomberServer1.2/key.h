#ifndef KEY_H
#define KEY_H


struct Key
{
	bool up;
	bool down;
	bool left; 
	bool right;
	bool b;
	 Key()
  {
    up=false;
    right=false;
    left=false;
    down=false;
    b=false;
  }
};

#endif // KEY_H