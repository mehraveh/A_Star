#include <iostream>
#include <vector>
#include "A_Star.cpp"
using namespace std;
int main()
{
	Board* board = new Board(1);
	A_Star* a = new A_Star();
	board->printBoard();
	int** path = new int*[10];
		for( int i = 0 ; i < 10 ; i++ )
		{
			path[i] = new int [2];
		}
   cout <<"Source"<< board->iDest <<"   " << board->jDest<<endl;
   cout <<"Source"<< board->iSource <<"   " << board->jSource<<endl;
      path = a->findPath(*board);

   for(int i = 0 ; i < 7 ;  i++)
   {
   	 cout << "i:" << path[i][0] << "  j:" << path[i][1] << endl;
   }
   cout << "dist :" << a->shortDist;

}