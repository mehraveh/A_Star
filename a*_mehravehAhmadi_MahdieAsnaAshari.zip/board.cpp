#include <iostream>
#include <vector>
using namespace std;
class Board
{
public:
   // std::vector<vector <char> > board;
	char board[10][10];
	int iSource;
	int jSource;
	int iDest;
	int jDest;
    Board(int num ){
    for (int i = 0; i < 10; i++)
    {
    	for (int j = 0; j < 10; j++)
    	{
    		board[i][j] = '-';
    	}
    }
    if( num == 1)
    {
    	board[5][2] = 'o';
    	board[5][3] = 'o';
    	board[5][4] = 'o';
    	board[5][5] = 'o';
    	board[5][6] = 'o';
    	board[3][3] = 's';
    	board[8][4] = 'd';
    	iSource = 3;
    	jSource = 4;
    	iDest = 8;
    	jDest = 4;
    }
}
Board()
{
        board[5][2] = 'o';
    	board[5][3] = 'o';
    	board[5][4] = 'o';
    	board[5][5] = 'o';
    	board[5][6] = 'o';
    	board[3][3] = 's';
    	board[8][4] = 'd';
    	iSource = 3;
    	jSource = 4;
    	iDest = 8;
    	jDest = 4;
	
}
void updateSource( int inewSource , int jnewSource)
{

	iSource = inewSource;
	jSource = jnewSource;

}
void updateBoard(){
	for( int i = 0 ; i < 10 ; i++)
	{
		 for( int j = 0 ; j < 10 ; j++)
		 {
		 	board[i][j] = '-';

		 }
	}
	board[5][2] = 'o';
	board[5][3] = 'o';
    	board[5][4] = 'o';
    	board[5][5] = 'o';
    	board[5][6] = 'o';
    	board[iSource][jSource] = 's';
    	board[8][4] = 'd';

}
 void printBoard()
 {
 	for (int i = 0; i < 10; i++)
    {
    	for (int j = 0; j < 10; j++)
    	{
    		 cout << board[i][j] << "  ";
    	}
    	cout << endl;
    }
 }
};
