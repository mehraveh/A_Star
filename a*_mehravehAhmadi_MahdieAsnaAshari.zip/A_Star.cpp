#include <iostream>
#include "board.cpp"
#include <cmath>
class A_Star
{
public:
	Board* board;

    int shortDist;

	A_Star()
	{
        board = new Board(1);
    	board->board[5][2] = 'o';
    	board->board[5][3] = 'o';
    	board->board[5][4] = 'o';
    	board->board[5][5] = 'o';
    	board->board[5][6] = 'o';
    	board->board[3][3] = 's';
    	board->board[8][4] = 'd';
    	board->iSource = 3;
    	board->jSource = 4;
    	board->iDest = 8;
    	board->jDest = 4;
       shortDist = 0;

	}
	~A_Star(){

	}
	int huristic(int is , int id , int js , int  jd)
	{
		int i = 0 ; int j = 0 ;
		int distance = 0 ;
		
             //distance = abs( board.iDest - board.iSource);
             //i = abs( board.iDest - board.iSource);
		
             distance = abs(jd - js) + abs( id - is) ;
             //j = abs(board.jDest - board.jSource);
		//cout << distance;
		return distance;
	}
	int** findPath(Board &board)
	{
		int max = 1000;
		int imax;
		int jmax;
		int** path = new int*[100];
		for( int i = 0 ; i < 100 ; i++ )
		{
			path[i] = new int [2];
		}
		int** dist = new int*[10];
		for( int i = 0 ; i < 10 ; i++ )
		{
			dist[i] = new int [10];
		}
		bool** exp = new bool*[10];
		for( int i = 0 ; i < 10 ; i++ )
		{
			exp[i] = new bool [10];
		}
		
		for( int i = 0 ; i < 10 ; i++)
		{
			for(int j = 0 ; j < 10 ; j++)
			{
				dist[i][j] = 0;
				exp[i][j] = false;
			}
		}
		int r =0;
		int counter = 0;
		//cout <<"huristic"<<huristic(board)<<endl;
		while(!((board.iSource == board.iDest) &&(board.jSource == board.jDest)) )
		{
		   max = 1000;
		 
        int i = board.iSource;
        int j = board.jSource;
		if (i >= 0 && i<10 && j >= 0 && j<9 && board.board[i][j+1] != 'o' && !exp[i][j+1])
		{  
			cout <<"huristic"<<huristic(i,board.iDest , j+1 , board.jDest)<<endl;
			exp[i][j] = true;
			dist[i][j+1] = 1+huristic(i ,board.iDest , j+1 , board.jDest);
			if(max > dist[i][j+1]){
			max = dist[i][j+1];
			imax = i;
			jmax = j+1;}
		}
		if (i >= 0 && i<10 && j > 0 && j<10 && board.board[i][j-1] != 'o'  && !exp[i][j-1])
		{  			cout <<"huristic"<<huristic(i ,board.iDest , j-1 , board.jDest)<<endl;
exp[i][j] = true;
			dist[i][j-1] = 1+huristic(i ,board.iDest , j-1 , board.jDest);
			if(max > dist[i][j-1]){
			max = dist[i][j-1];
			imax = i;
			jmax = j-1;}
		}
		if (i >= 0 && i<9 && j >= 0 && j<10 && board.board[i+1][j] != 'o'  )
		{
						cout <<"huristic"<<huristic(i+1 ,board.iDest , j , board.jDest)<<endl;
        exp[i][j] = true;
			//int iTmp = i+1;
			dist[i+1][j] = 1+huristic(i+1 ,board.iDest , j , board.jDest);
			if(max > dist[i+1][j]){
			max= dist[i+1][j];
			imax = i+1;
			jmax = j;}
		}
		if (i > 0 && i<10 && j >= 0 && j<10 && board.board[i-1][j] != 'o' && !exp[i- 1][j])
		{  			cout <<"huristic"<<huristic(i-1 ,board.iDest , j , board.jDest)<<endl;
exp[i][j] = true;
			dist[i-1][j] = 1+huristic(i-1 ,board.iDest , j , board.jDest);
			if(max > dist[i-1][j]){
			max =dist[i-1][j];
			imax = i -1;
			jmax = j;}
		}

        
		//board.updateSource(imax , jmax);
		board.iSource = imax;
		board.jSource = jmax;
		path[counter][0] = imax;
		path[counter][1] = jmax;
		counter++;
		board.updateBoard();
		board.printBoard();

	}
			shortDist = counter;

           return path;

	}
	
};