#include "enemy.h"

Enemy::Enemy()
{
    isAlive = true;
    raft = true;
}
  void Enemy::setX( int x)
    {
    }
    int Enemy::getX()
    {  
    }
    void Enemy::setY( int y)
    {    
    }
    int Enemy::getY()
    {   
    }
    void Enemy::setLeftBoard( int leftBoard)
    {  
    }
    int Enemy::getLeftBoard()
    {   
    }
    void Enemy::setRightBoard( int rightBoard)
    {
    }
    int Enemy::getRightBoard()
    {  
    }
    void Enemy::setUpBoard( int upBoard)
    {  
    }
    int Enemy::getUpBoard()
    {   
    }
    void Enemy::setDownBoard( int downBoard)
    {   
    }
    int Enemy::getDownBoard()
    {  
    }
  
    void Enemy::move(Player &player1,Player &player2, Board &board)
    {
    }
    char Enemy::getTypee()
    {}
    void Enemy::addX()
    {}
     void Enemy::kamX()
     {}
     double Enemy::getCurX()
     {} 
      void Enemy::setCurX(double c){}
      double Enemy::getCurY()
     {} 
      void Enemy::setCurY(double c){}

