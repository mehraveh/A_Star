#ifndef BAT_H
#define BAT_H
#include "enemy.h"

class Bat : public Enemy
{
public:
    Bat();
       void setX( int x);
     int getX();
     void setY( int y);
     int getY();
     void setLeftBoard( int leftBoard);
     int getLeftBoard();
     void setRightBoard( int rightBoard);
     int getRightBoard();
     void setUpBoard( int upBoard);
     int getUpBoard();
     void setDownBoard( int downBoard);
     int getDownBoard();
    
     void move(Player &player ,Player &player2, Board &board);
     char getTypee();
      void addX();
     void kamX();
     double getCurX();
     double getCurY(); 
     void setCurY(double c);
};

#endif // BAT_H
