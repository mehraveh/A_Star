#include "rabbit.h"
#include "enemy.h"

Rabbit::Rabbit():Enemy()
{
  setLeftBoard(3);
  setRightBoard(3);
}
  void Rabbit::setX( int x)
    {
    	this-> x=x;
    }
    int Rabbit::getX()
    {
    	return x;
    }
    void Rabbit::setY( int y)
    {
    	this-> y = y;
    }
    int Rabbit::getY()
    {
    	return y;
    }
    void Rabbit::setLeftBoard( int leftBoard)
    {
    	this->leftBoard = leftBoard;
    }
    int Rabbit::getLeftBoard()
    {
    	return leftBoard;
    }
    void Rabbit::setRightBoard( int rightBoard)
    {
    	this-> rightBoard = rightBoard;
    }
    int Rabbit::getRightBoard()
    {
    	return rightBoard;
    }
    void Rabbit::setUpBoard( int upBoard)
    {
    	this -> upBoard = upBoard;
    }
    int Rabbit::getUpBoard()
    {
    	return upBoard;
    }
    void Rabbit::setDownBoard( int downBoard)
    {

    	this -> downBoard = downBoard;    	
    }
    int Rabbit::getDownBoard()
    {
    	 return downBoard;
    }
     void Rabbit::addX()
    {
        curX += 0.5f;
    }
     void Rabbit::kamX()
    {
        curX -= 0.5f ;
    }
    double Rabbit:: getCurX()
    {
        return curX;
    }
   void Rabbit::setCurX(double c)
   {
        curX = c;
   }
	double Rabbit::getCurY()
	{
		return y;
	}
    char Rabbit::getTypee()
     {
        return 'r';
     }
    void Rabbit::move(Player &player1,Player &player2, Board &board)
    {
		
		if(player1.getX() == getCurX() && player1.getY() == getY() ) player1.setLife(player1.getLife()-1); 
    	if(player2.getX() == getCurX() && player2.getY() == getY() ) player2.setLife(player2.getLife()-1); 
    	

    if(getCurX() < getX() + getRightBoard() && raft == true) 
            {
				if(board.game_board[(int)getCurX()+1][(int)getY()] == 'e' || board.game_board[(int)getCurX()+1][(int)getY()] == 'b')
				{
					 setCurX(getCurX());
					 raft = false;
				}
					 else{
                addX(); 
                raft = true;
            }}
        if (getCurX() == getX() + getLeftBoard()) raft =false;
        if(raft == false) kamX();
        if(getCurX() <= getX()) raft = true;

       } 
    

