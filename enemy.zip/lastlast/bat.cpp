#include "bat.h"

Bat::Bat():Enemy()
{
   setUpBoard(2);
   setDownBoard(2);
}
  void Bat::setX( int x)
    {
    	this-> x=x;
    }
    int Bat::getX()
    {
    	return x;
    }
    void Bat::setY( int y)
    {
    	this-> y = y;
    }
    int Bat::getY()
    {
    	return y;
    }
    void Bat::setLeftBoard( int leftBoard)
    {
    	this->leftBoard = leftBoard;
    }
    int Bat::getLeftBoard()
    {
    	return leftBoard;
    }
    void Bat::setRightBoard( int rightBoard)
    {
    	this-> rightBoard = rightBoard;
    }
    int Bat::getRightBoard()
    {
    	return rightBoard;
    }
    void Bat::setUpBoard( int upBoard)
    {
    	this -> upBoard = upBoard;
    }
    int Bat::getUpBoard()
    {
    	return upBoard;
    }
    void Bat::setDownBoard( int downBoard)
    {

    	this -> downBoard = downBoard;    	
    }
    int Bat::getDownBoard()
    {
    	 return downBoard;
    }
   
    void Bat::addX()
    {
        curY += 0.5f;
    }
    void Bat::kamX()
    {
        curY -= 0.5f ;
    }
    double Bat:: getCurY()
    {
        return curY;
    }
    double Bat:: getCurX()
    {
        return x;
    }
   void Bat::setCurY(double c)
   {
        curY = c;
   }
    char Bat::getTypee()
    {
        return 'b';
    }
    void Bat::move(Player &player1 ,Player &player2, Board &board)
    {
    	if(player1.getX() == getX() && player1.getY() == getCurY() ) player1.setLife(player1.getLife()-1); 
    	if(player2.getX() == getX() && player2.getY() == getCurY() ) player2.setLife(player2.getLife()-1); 
    	
    	
    	/*if(getCurY() < getY() + getUpBoard() && raft == true) 
           {
			   if(board.game_board[(int)getX()][(int)getCurY()+1] == 'e' || board.game_board[(int)getX()][(int)getCurY()+1] == 'b')
				{
					 setCurY(getCurY());
					 raft = false;
				 }
				 else{
                addX(); 
                raft = true;
            }}
        if (getCurY() == getY() + getDownBoard()) raft =false;
        if(raft == false) 
        {
			
			kamX();
		}
        if(getCurY() <= getY()) raft = true;*/
    }
