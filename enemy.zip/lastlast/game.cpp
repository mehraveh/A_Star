#include "game.h"
#include  <iostream>
#include <string>
#include <fstream>
#include <ctime>
using namespace std;
Game::Game()
{
	received = 0;
	bmb = false;
// srand(time(0));
}
void Game::Board_Cout( Board &board)
{
	for (int i = 0; i < 17; i++)
	{
		for (int j = 0; j < 17; j++)
		{
			cout<<board.game_board[i][j]<<" ";
		}
		cout<<endl;
	}
}
Key* Game::setKeys1(GraphicBomber &graphic ,Key &key ,Player &player)
{
	key.right=graphic.dKeyPressed();
	key.left=graphic.aKeyPressed();
	key.up=graphic.wKeyPressed();
	key.down = graphic.sKeyPressed();
	if(key.right || key.left || key.up || key.down)
	{
	cout<<"x="<<player.getX()<<endl;
    cout<<"y="<<player.getY()<<endl;}
    
	return &key;
}
Key* Game::setKeys2(GraphicBomber &graphic ,Key &key ,Player &player ,char* buffer)
{
	if(buffer[0] == 'r')
       {key.right=true;
        key.left=false;
		key.up = false;
		key.down = false;}
       // else
        //key.right=false;
    else if(buffer[0] == 'l')
	   {key.left=true;
        key.right=false;
        key.up = false;
		key.down = false;
	   }
	    //else
        //key.left=false;
	else if(buffer[0] == 'u')
		{key.up = true;
		key.right=false;
		key.left=false;
		key.down = false ;}
		 //else
        //key.up=false;
	 else if(buffer[0] == 'd')
	   {key.down = true ;
	   	key.right=false;
		key.left=false;
		key.up = false;}
	   // else
        //key.down=false;
        else 
        {key.right=false;
		key.left=false;
		key.up = false;
		key.down = false ;
			
			}
	if(key.right || key.left || key.up || key.down)
	{
	cout<<"x="<<player.getX()<<endl;
    cout<<"y="<<player.getY()<<endl;}
    
	return &key;
}
 string Game::sendKey(Key &key)
 {
 	
    	if (key.up)
	{
		message = 'u';
		//cout<<"u"<<endl;
		//y=-42;
	}
	 if (key.down)
	{
		message = 'd';
	
	}
	else if (key.right)
	{
		//cout<<"r"<<endl;
		message = 'r';
		//x=+42;
	}
	else if (key.left)
	{
		//cout<<"l"<<endl;
		message = 'l';
		//x-=42;
	}
	else
	  message = 'n';
	return message;
 }
Gift ** Game::locateGift( Board &board)
{
	bool b;
	int t1 ,t2;
	bool**giftLoc;
		giftLoc = new bool *[17];
	for (int i = 0; i <17; i++)
	{
		
		giftLoc[i] = new bool [17];
	}
	for( int i = 0 ; i < 17 ;i++)
		for( int j = 0 ; j < 17 ;j++)
			giftLoc[i][j]=false;
	Gift ** tmp = new Gift* [10];
   srand(time(0));
	   for ( int  i = 0 ; i < 10 ; i++ )
	   {
	   	b = rand()%2;
        if(b)
        {
        	
        	tmp[i] = new LifePlus();
        	cout<<"l"<<endl;
        }
        else
        {
        
        	tmp[i] = new BombPlus();
        	cout<<"b"<<endl;
        }
	 
	do{
		
		
		tmp[i]->setX(rand()%17);
		tmp[i]->setY(rand()%17);
		
     

  }	while(board.game_board[tmp[i]->getX()][tmp[i]->getY()]!='e'  ||giftLoc[tmp[i]->getX()][tmp[i]->getY()]==1);
cout<<tmp[i]->getX()<<" "<<tmp[i]->getY()<<endl;
giftLoc[tmp[i]->getX()][tmp[i]->getY()]=1;
}
    return tmp;
}
void Game::giftApply(Player &player ,Gift ** gift , Bomb &bomb )
{
	for(int i = 0 ;i<10 ;i++)
	{
		if(player.getX() == gift[i]->getX() && player.getY() == gift[i]->getY() && gift[i]->isSeen == false)
			{
				gift[i]->rangAdder(bomb);
				gift[i]->addLife(player);
				gift[i]->isSeen = true;
					
  	    }
		
    }
}


Enemy ** Game::locateEnemy( Board &board)
{
	bool be;
	bool**enemyLoc;
		enemyLoc = new bool *[17];
	for (int i = 0; i <17; i++)
	{
		
		enemyLoc[i] = new bool [17];
	}
	for( int i = 0 ; i < 17 ;i++)
		for( int j = 0 ; j < 17 ;j++)
			enemyLoc[i][j]=false;
	Enemy ** tmpEnemy = new Enemy* [5];
   srand(time(0));
	   for ( int  i = 0 ; i < 5 ; i++ )
	   {
	   	be = rand()%2;
        if(be)
        {
        	
        	tmpEnemy[i] = new Rabbit();
        	cout<<"Rabiiiiiiiiiiiiiiiiiiit"<<endl;
        }
        else
        {
        
        	tmpEnemy[i] = new Bat();
        	cout<<"baaaaaaaaaaaaaaaaaaaaaaat"<<endl;
        }
	 
	  do{
		
		tmpEnemy[i]->setX(rand()%17);
		tmpEnemy[i]->setY(rand()%17);
		
     

  }	while(board.game_board[tmpEnemy[i]->getX()][tmpEnemy[i]->getY()]!='n' ||enemyLoc[tmpEnemy[i]->getX()][tmpEnemy[i]->getY()]==1);
cout<<tmpEnemy[i]->getX()<<" "<<tmpEnemy[i]->getY()<<endl;
enemyLoc[tmpEnemy[i]->getX()][tmpEnemy[i]->getY()]=1;
tmpEnemy[i]->setCurX( tmpEnemy[i]->getX()) ;
tmpEnemy[i]->setCurY( tmpEnemy[i]->getY()) ;
}
    return tmpEnemy;
}

void Game::enemyApply(Player &player1 ,Player &player2, Enemy ** enemy, Board &board )
{
	for(int i = 0 ;i<5 ;i++)
	{
		if( enemy[i]->isAlive == true)
			{
				enemy[i]->move(player1, player2, board);
				
					
  	    }
		
    }
}
bool Game::isAlive(Player &player)
{
	if(player.getLife() <  0 || player.getLife() == 0)
	    return false;
	else
	{
		
	    return true;}
	
}
string Game::sendBomb(Key &key)
  {
      if (key.b)
  {
    message = 'b';
  
  }
   else 
     message = 'n';
   return message ;

  }
void Game::run(GraphicBomber &graphic, Key &key1, Key &key2 , Player &player1 ,Player &player2 , Board &board ,Bomb &bomb1 ,Bomb &bomb2 ,Gift**gift ,char *buffer, TcpSocket *socket,Enemy** enemy)
{
	
	key1= *(setKeys1(graphic ,key1 ,player1));
	player1.moveControl(key1,board);
	socket->send(sendKey(key1).c_str(),sendKey(key1).size() + 1); 
	socket->receive(buffer, sizeof(buffer), received);		
    player2.moveControl(*(setKeys2(graphic ,key2 ,player2 , buffer )),board);
    
    bomb1.bombIsLocated(key1 ,player1,graphic.bKeyPressed());
    bomb1.boardUpdater(board , player1 , player2 , enemy);
    bomb2.bombIsLocated(key2,player2,graphic.mKeyPressed());
    bomb2.boardUpdater(board , player1 , player2 , enemy);
    giftApply(player1 , gift ,bomb1);
    giftApply(player2 , gift ,bomb2);
    enemyApply(player1,player2,enemy, board);
  
    
}

