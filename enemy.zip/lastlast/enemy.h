#ifndef ENEMY_H
#define ENEMY_H
#include "board.h"
#include "player.h"
//#include "bomb.h"
//#include "lifeplus.h"
//#include "bombplus.h"
#include <cstdlib>
#include <ctime>

class Enemy
{
protected:
	int x;
	int y;
	int leftBoard;
	int rightBoard;
	int upBoard;
	int downBoard;
	double speed;
    double curX;
    double curY;


public:
    Enemy();
    bool isAlive;
    bool raft;
    virtual void setX( int x);
    virtual int getX();
    virtual void setY( int y);
    virtual int getY();
    virtual void setLeftBoard( int leftBoard);
    virtual int getLeftBoard();
    virtual void setRightBoard( int rightBoard);
    virtual int getRightBoard();
    virtual void setUpBoard( int upBoard);
    virtual int getUpBoard();
    virtual void setDownBoard( int downBoard);
    virtual int getDownBoard();
    
    virtual void move(Player &player1,Player &player2, Board &board);
    virtual char getTypee();
    virtual void addX();
    virtual void kamX();
    virtual double getCurX(); 
    virtual void setCurX(double c);
    virtual double getCurY(); 
    virtual void setCurY(double c);
};

#endif // ENEMY_H
