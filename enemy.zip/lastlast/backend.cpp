#include "backend.h"
#include <ctime>

BackEnd::BackEnd()
{
	gift = new Gift*[10];
	enemy = new Enemy*[10];
	buffer = new char[2];

}
void BackEnd::run()
{
	
    TcpSocket *socket = new sf::TcpSocket();
    socket->connect("127.0.0.1", 55001);
	board.setWallType("map1.txt");
	game.Board_Cout(board);
	gift= game.locateGift(board);
	enemy = game.locateEnemy(board);
	while(game.isAlive(player1) && game.isAlive(player2))
	{
	     
		
	     game.run(graphic, key1 ,key2 ,player1 ,player2 , board ,bomb1 ,bomb2 , gift ,buffer, socket, enemy );
	     graphic.show(board , player1 , bomb1 ,player2 , bomb2, gift ,enemy);	
	   
}
cout<<"finished"<<endl;
}
