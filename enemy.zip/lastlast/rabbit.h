#ifndef RABBIT_H
#define RABBIT_H
#include "enemy.h"

class Rabbit:public Enemy
{
public:
    Rabbit();
     void setX( int x);
     int getX();
     void setY( int y);
     int getY();
     void setLeftBoard( int leftBoard);
     int getLeftBoard();
     void setRightBoard( int rightBoard);
     int getRightBoard();
     void setUpBoard( int upBoard);
     int getUpBoard();
     void setDownBoard( int downBoard);
     int getDownBoard();
     char getTypee();
    
     void move(Player &player1,Player &player2, Board &board);
     void addX();
     void kamX();
     double getCurX(); 
     double getCurY();
     void setCurX(double c);
};

#endif // RABBIT_H
