#ifndef LIFEPLUS_H
#define LIFEPLUS_H
#include "player.h"
#include "gift.h"
class LifePlus : public Gift
{
    public:
    LifePlus();
    void addLife(Player &player);
 
};

#endif // LIFEPLUS_H
