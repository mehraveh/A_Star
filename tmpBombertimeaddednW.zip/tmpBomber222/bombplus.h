#ifndef BOMBPLUS_H
#define BOMBPLUS_H
#include "gift.h"
#include "bomb.h"
class BombPlus : public Gift
{
public:
    BombPlus();
    int* randXY(Board &board);
    void boardAdder(Bomb &bomb);
};

#endif // BOMBPLUS_H
