#ifndef BOARD_H
#define BOARD_H
#include <fstream>
#include <string>
#include <iostream>
class Board
{
private:
	
public:

char** game_board;
    Board();
    void setWallType( std::string filename);
};

#endif // BOARD_H
