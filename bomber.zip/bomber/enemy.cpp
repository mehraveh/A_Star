#include "enemy.h"

Enemy::Enemy()
{
    isAlive = true;
}
  void Enemy::setX( int x)
    {
    }
    int Enemy::getX()
    {  
    }
    void Enemy::setY( int Y)
    {    
    }
    int Enemy::getY()
    {   
    }
    void Enemy::setLeftBoard( int leftBoard)
    {  
    }
    int Enemy::getLeftBoard()
    {   
    }
    void Enemy::setRightBoard( int rightBoard)
    {
    }
    int Enemy::getRightBoard()
    {  
    }
    void Enemy::setUpBoard( int upBoard)
    {  
    }
    int Enemy::getUpBoard()
    {   
    }
    void Enemy::setDownBoard( int downBoard)
    {   
    }
    int Enemy::getDownBoard()
    {  
    }
   /* void Enemy::setSpeed(int speed)
    {   
    }
    double Enemy::getSpeed()
    {   
    }*/
    void Enemy::move(Player &player, Board &board)
    {
    }
    

