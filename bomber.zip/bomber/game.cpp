#include "game.h"
#include "board.h"
#include  <iostream>
#include <string>
#include <fstream>
#include <ctime>
using namespace std;
Game::Game()
{
// srand(time(0));
}
void Game::Board_Cout( Board &board)
{
	for (int i = 0; i < 17; i++)
	{
		for (int j = 0; j < 17; j++)
		{
			cout<<board.game_board[i][j]<<" ";
		}
		cout<<endl;
	}
}
Key* Game::setKeys(GraphicBomber &graphic ,Key &key ,Player &player)
{
	key.right=graphic.rightKeyPressed();
	key.left=graphic.leftKeyPressed();
	key.up=graphic.upKeyPressed();
	key.down = graphic.downKeyPressed();
	if(key.right || key.left || key.up || key.down)
	{
	cout<<"x="<<player.getX()<<endl;
    cout<<"y="<<player.getY()<<endl;}
    
	return &key;
}
Gift ** Game::locateGift( Board &board)
{
	bool b;
	int t1 ,t2;
	bool**giftLoc;
		giftLoc = new bool *[17];
	for (int i = 0; i <17; i++)
	{
		
		giftLoc[i] = new bool [17];
	}
	for( int i = 0 ; i < 17 ;i++)
		for( int j = 0 ; j < 17 ;j++)
			giftLoc[i][j]=false;
	Gift ** tmp = new Gift* [10];
   srand(time(0));
	   for ( int  i = 0 ; i < 10 ; i++ )
	   {
	   	b = rand()%2;
        if(b)
        {
        	
        	tmp[i] = new LifePlus();
        	cout<<"l"<<endl;
        }
        else
        {
        
        	tmp[i] = new BombPlus();
        	cout<<"b"<<endl;
        }
	 
	do{
		
		t1=rand()%17;
		t2=rand()%17;
		tmp[i]->setX(rand()%17);
		tmp[i]->setY(rand()%17);
		
     

  }	while(board.game_board[tmp[i]->getX()][tmp[i]->getY()]!='e'  ||giftLoc[tmp[i]->getX()][tmp[i]->getY()]==1);
cout<<tmp[i]->getX()<<" "<<tmp[i]->getY()<<endl;
giftLoc[tmp[i]->getX()][tmp[i]->getY()]=1;
}
    return tmp;
}
void Game::giftApply(Player &player ,Gift ** gift , Bomb &bomb)
{
	for(int i = 0 ;i<10 ;i++)
	{
		if(player.getX() == gift[i]->getX() && player.getY() == gift[i]->getY() && gift[i]->isSeen == false)
			{
  				 BombPlus* bp =static_cast<BombPlus*>(gift[i]);
  			     if(bp != NULL)
					
					{
						bp->rangAdder(bomb);
						cout<<"bP:"<<bomb.getDownRang()<<endl;
					}
   
	  			  else
					
					{
						LifePlus* lp =static_cast<LifePlus*>(gift[i]);
						lp->addLife(player);
						cout<<"lP:"<<player.getLife()<<endl;
					}
				    gift[i]->isSeen = true;
					
  	}
		
    }
}

Enemy ** Game::locateEnemy( Board &board)
{
	bool be;
	int t1e ,t2e;
	bool**enemyLoc;
		enemyLoc = new bool *[17];
	for (int i = 0; i <17; i++)
	{
		
		enemyLoc[i] = new bool [17];
	}
	for( int i = 0 ; i < 17 ;i++)
		for( int j = 0 ; j < 17 ;j++)
			enemyLoc[i][j]=false;
	Enemy ** tmpEnemy = new Enemy* [10];
   srand(time(0));
	   for ( int  i = 0 ; i < 10 ; i++ )
	   {
	   	be = rand()%2;
        if(be)
        {
        	
        	tmpEnemy[i] = new Rabbit();
        	cout<<"r"<<endl;
        }
        else
        {
        
        	tmpEnemy[i] = new Bat();
        	cout<<"bat"<<endl;
        }
	 
	do{
		
		t1e=rand()%17;
		t2e=rand()%17;
		tmpEnemy[i]->setX(rand()%17);
		tmpEnemy[i]->setY(rand()%17);
		
     

  }	while(board.game_board[tmpEnemy[i]->getX()][tmpEnemy[i]->getY()]!='e'  ||enemyLoc[tmpEnemy[i]->getX()][tmpEnemy[i]->getY()]==1);
cout<<tmpEnemy[i]->getX()<<" "<<tmpEnemy[i]->getY()<<endl;
enemyLoc[tmpEnemy[i]->getX()][tmpEnemy[i]->getY()]=1;
}
    return tmpEnemy;
}
void Game::enemyApply(Player &player ,Enemy ** enemy ,Board &board)
{
	for(int i = 0 ;i<10 ;i++)
	{
		if(enemy[i]->isAlive == true){
  				 
					
					
						enemy[i]->move(player,board);
						//cout<<"rabbit"<<endl;
			
						//cout<<"bat"<<endl;
					}
				   }
    
}
void Game::run(GraphicBomber &graphic, Key &key , Player &player , Board &board ,Bomb &bomb ,Gift**gift, Enemy ** enemy)
{
	
	
	
    player.moveControl(*(setKeys(graphic ,key ,player)),board);
    bomb.bombIsLocated(key ,player,graphic.bKeyPressed());
    bomb.boardUpdater(board , player , player ,enemy);
    giftApply(player , gift ,bomb);
    enemyApply(player , enemy,board );
  
    

    
    
}

