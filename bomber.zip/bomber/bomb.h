#ifndef BOMB_H
#define BOMB_H
//#include "board.h"
#include "player.h"
#include "enemy.h"
#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Window/Mouse.hpp>
#include <ctime>
using namespace sf;
using namespace std;
class Bomb
{
private:
	int x;
	int y;
	int leftRang;
	int rightRang;
	int upRang;
	int downRang;
	int exTime;
    int timeE;

public:
    bool bombLocated;
    Bomb();
    void setX( int x);
    int getX();
    void setY( int y);
    int getY();
    void setLeftRang( int leftRang);
    int getLeftRang();
    void setRightRang( int rightRang);
    int getRightRang();
    void setUpRang( int upRang);
    int getUpRang();
    void setDownRang( int downRang);
    int getDownRang();
    void setEXTime( int exTime);
    int getExTime();
    void  bombIsLocated( Key &key  ,Player &player , bool bo);
    bool bombIsExploded();
    void  boardUpdater(Board &board,Player &p1, Player &p2, Enemy **enemy);
    

};

#endif // BOMB_H
