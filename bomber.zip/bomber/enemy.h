#ifndef ENEMY_H
#define ENEMY_H
#include "board.h"
#include "player.h"
//#include "bomb.h"
//#include "lifeplus.h"
//#include "bombplus.h"
#include <cstdlib>
#include <ctime>

class Enemy
{
protected:
	int x;
	int y;
	int leftBoard;
	int rightBoard;
	int upBoard;
	int downBoard;
	double speed;
    

public:
    Enemy();
    bool isAlive;
    virtual void setX( int x);
    virtual int getX();
    virtual void setY( int Y);
    virtual int getY();
    virtual void setLeftBoard( int leftBoard);
    virtual int getLeftBoard();
    virtual void setRightBoard( int rightBoard);
    virtual int getRightBoard();
    virtual void setUpBoard( int upBoard);
    virtual int getUpBoard();
    virtual void setDownBoard( int downBoard);
    virtual int getDownBoard();
    //virtual void setSpeed(int speed);
   // virtual double getSpeed();
    virtual void move(Player &player, Board &board);

};

#endif // ENEMY_H