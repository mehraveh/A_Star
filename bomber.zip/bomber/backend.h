#ifndef BACKEND_H
#define BACKEND_H
#include "game.h"

class BackEnd
{private:
	Game game;
	Player player;
	Board board;
	Key key;
	Bomb  bomb;
	GraphicBomber graphic;
	Gift**gift;
	Enemy ** enemy;
public:
    BackEnd();
    void run();
};

#endif // BACKEND_H