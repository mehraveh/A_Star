#include "bat.h"

Bat::Bat():Enemy()
{
   setLeftBoard(5);
   setRightBoard(5);
}
  void Bat::setX( int x)
    {
    	this-> x=x;
    }
    int Bat::getX()
    {
    	return x;
    }
    void Bat::setY( int Y)
    {
    	this-> y = y;
    }
    int Bat::getY()
    {
    	return y;
    }
    void Bat::setLeftBoard( int leftBoard)
    {
    	this->leftBoard = leftBoard;
    }
    int Bat::getLeftBoard()
    {
    	return leftBoard;
    }
    void Bat::setRightBoard( int rightBoard)
    {
    	this-> rightBoard = rightBoard;
    }
    int Bat::getRightBoard()
    {
    	return rightBoard;
    }
    void Bat::setUpBoard( int upBoard)
    {
    	this -> upBoard = upBoard;
    }
    int Bat::getUpBoard()
    {
    	return upBoard;
    }
    void Bat::setDownBoard( int downBoard)
    {

    	this -> downBoard = downBoard;    	
    }
    int Bat::getDownBoard()
    {
    	 return downBoard;
    }
   /* void Bat::setSpeed(int speed)
    {
    	this -> speed = speed;
    }
    double Bat::getSpeed()
    {
    	return speed;
    }*/
    void Bat::move(Player &player , Board &board)
    {
    	std::cout << "baaat is moving "<< std:: endl;
    }
