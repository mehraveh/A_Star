#ifndef RABBIT_H
#define RABBIT_H
#include "enemy.h"

class Rabbit:public Enemy
{
public:
    Rabbit();
     void setX( int x);
     int getX();
     void setY( int Y);
     int getY();
     void setLeftBoard( int leftBoard);
     int getLeftBoard();
     void setRightBoard( int rightBoard);
     int getRightBoard();
     void setUpBoard( int upBoard);
     int getUpBoard();
     void setDownBoard( int downBoard);
     int getDownBoard();
    // void setSpeed(int speed);
     //double getSpeed();
     void move(Player &player, Board &board);
};

#endif // RABBIT_H
