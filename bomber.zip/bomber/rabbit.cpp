#include "rabbit.h"
#include "enemy.h"

Rabbit::Rabbit():Enemy()
{
  setLeftBoard(2);
  setRightBoard(2);
}
  void Rabbit::setX( int x)
    {
    	this-> x=x;
    }
    int Rabbit::getX()
    {
    	return x;
    }
    void Rabbit::setY( int Y)
    {
    	this-> y = y;
    }
    int Rabbit::getY()
    {
    	return y;
    }
    void Rabbit::setLeftBoard( int leftBoard)
    {
    	this->leftBoard = leftBoard;
    }
    int Rabbit::getLeftBoard()
    {
    	return leftBoard;
    }
    void Rabbit::setRightBoard( int rightBoard)
    {
    	this-> rightBoard = rightBoard;
    }
    int Rabbit::getRightBoard()
    {
    	return rightBoard;
    }
    void Rabbit::setUpBoard( int upBoard)
    {
    	this -> upBoard = upBoard;
    }
    int Rabbit::getUpBoard()
    {
    	return upBoard;
    }
    void Rabbit::setDownBoard( int downBoard)
    {

    	this -> downBoard = downBoard;    	
    }
    int Rabbit::getDownBoard()
    {
    	 return downBoard;
    }
   /* void Rabbit::setSpeed(int speed)
    {
    	this -> speed = speed;
    }
    double Rabbit::getSpeed()
    {
    	return speed;
    }*/
    void Rabbit::move(Player &player, Board &board)
    {
    	std:: cout << "rabbbit is moving "<< std::endl;
        int s = getX();
        int f = getX() + getRightBoard();
         if(s<f){
         if(board.game_board[s][getY()]=='b'|| board. game_board[s][getY()]=='e'){
            setX(getX());
         }
else{
        
        
            setX(getX()+1);
             if(player.getX()==getX()) player.setLife(player.getLife()-1);
        }
        
        }
        if(s>=f){
             if(board.game_board[s][getY()]=='b'|| board. game_board[s][getY()]=='e'){
            setX(getX());
         }
else{
        
        
            setX(getX()-1);
             if(player.getX()==getX()) player.setLife(player.getLife()-1);
        }
        }
               
       } 
    

