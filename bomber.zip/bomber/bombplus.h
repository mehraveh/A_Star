#ifndef BOMBPLUS_H
#define BOMBPLUS_H
#include "gift.h"
#include "bomb.h"
class BombPlus : public Gift
{
public:
    BombPlus();
    void rangAdder(Bomb &bomb);
};

#endif // BOMBPLUS_H
