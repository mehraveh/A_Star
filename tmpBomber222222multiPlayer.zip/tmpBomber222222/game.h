#ifndef GAME_H
#define GAME_H
#include <string>
#include <fstream>
#include "player.h"
#include "GraphicBomber.h"
#include "bomb.h"
#include "gift.h"
#include "bombplus.h"
#include "lifeplus.h"
class Game
{
public:
    Game();
   void  Board_Cout( Board &board);
   Key* setKeys1(GraphicBomber &graphic ,Key &key ,Player &player);
    Key* setKeys2(GraphicBomber &graphic ,Key &key,Player &player);
   Gift**locateGift(Board &board);
   bool isAlive(Player &player);
   void giftApply(Player &player ,Gift ** gift , Bomb &bomb);
   void run(GraphicBomber &graphic, Key &key1,Key &key2 , Player &player1 ,Player &player2 , Board &board ,Bomb &bomb1 ,Bomb &bomb2 ,Gift**gift);
};

#endif // GAME_H
