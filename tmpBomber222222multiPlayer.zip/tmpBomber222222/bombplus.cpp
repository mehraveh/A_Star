#include "bombplus.h"
#include "gift.h"
BombPlus::BombPlus():Gift()
{
   
}

 void BombPlus::rangAdder(Bomb &bomb)
    {
    	bomb.setUpRang(bomb.getUpRang()+1);
    	bomb.setDownRang(bomb.getDownRang()+1);
    	bomb.setRightRang(bomb.getRightRang()+1);
    	bomb.setLeftRang(bomb.getLeftRang()+1);
    }
char  BombPlus::getType()
{
   return 'B';
}
