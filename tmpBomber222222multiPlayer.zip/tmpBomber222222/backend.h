#ifndef BACKEND_H
#define BACKEND_H
#include "game.h"
#include <cstdlib>
class BackEnd
{private:
	Game game;
	Player player1;
	Board board;
	Key key1;
	Bomb  bomb1;
	GraphicBomber graphic;
	Gift**gift;
public:
	Player player2;
	Key key2;
	Bomb  bomb2;
    BackEnd();
    void run();
};

#endif // BACKEND_H
