#include "GraphicBomber.h"
using namespace sf;
	GraphicBomber::GraphicBomber()
	{
        window = new RenderWindow (VideoMode(714,714), "bomber man !");
		rectangle = new RectangleShape* [17];
		for( int i = 0 ; i < 17 ;i++)
		{
			rectangle[i] = new RectangleShape[17];
		}

	}
	

	
	/*void GraphicBomber::LoadTexture( Texture &texture , string filename)
		{
			 texture.loadFromFile(filename.c_str());
		}*/
		   void GraphicBomber::LoadTexture1( Texture &texture )
		{
			 texture.loadFromFile("noWall2.jpg");
		}
		void GraphicBomber::LoadTexture2( Texture &texture )
		{
			 texture.loadFromFile("noWall2.jpg");
		}
		void GraphicBomber::LoadTexture3( Texture &texture )
		{
			 texture.loadFromFile("brick.jpg");
		}
		void GraphicBomber::LoadTexture4( Texture &texture )
		{
			 texture.loadFromFile("exAbleWall.jpg");
		}
	void GraphicBomber::load()//----------------------load pics
    {
    	LoadTexture3(brick );
    	LoadTexture4(exAbleWall );
    	LoadTexture1(noWall1 );
    	LoadTexture2(noWall2 );
    }
	 void GraphicBomber::clearScreen(){
            window->clear();

        }

	 void GraphicBomber::closeWindow()
         {
             window->close();
             
       }
     bool GraphicBomber::isWindowOpen()
     {
             return window->isOpen();
      }
      void GraphicBomber::display(){
       window->display();

  }

    void GraphicBomber::drawRect(RectangleShape **r,int i , int j){
     window->draw(r[i][j]);
     }
     void GraphicBomber::drawCir(CircleShape &circle){
     window->draw(circle);
     }
	  bool GraphicBomber::rightKeyPressed(){
	     if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
	    {  
	        return true;}
	     else 
	        return false;
	}

	bool GraphicBomber::upKeyPressed(){
	     if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
	          return true;
	       else 
	          return false;
	}
	bool GraphicBomber::downKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
	         return true;
	  else 
	         return false;
	}
	bool GraphicBomber::bKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::B))
	        {
	         return true;}
	  else 
	         return false;
	}
		bool GraphicBomber::leftKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
	         {
	         	
	         	return true;
	         }
	  else 
	         return false;
	}
		bool GraphicBomber::mKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::M))
	         {
	         	
	         	return true;
	         }
	  else 
	         return false;
	}
		bool GraphicBomber::sKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
	         {
	         	
	         	return true;
	         }
	  else 
	         return false;
	}
		bool GraphicBomber::wKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
	         {
	         	
	         	return true;
	         }
	  else 
	         return false;
	}
		bool GraphicBomber::aKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
	         {
	         	
	         	return true;
	         }
	  else 
	         return false;
	}

		bool GraphicBomber::dKeyPressed(){
	  if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
	         {
	         	
	         	return true;
	         }
	  else 
	         return false;
	}

	    void GraphicBomber::setTextureCBrike(RectangleShape ** rectangle,int i , int j)
  		{
   			 rectangle[i][j].setTexture(&brick);
   		}
   		 void GraphicBomber::setTextureCExAbleWall(RectangleShape ** rectangle,int i , int j)
  		{
   			 rectangle[i][j].setTexture(&exAbleWall);
   		}
   		 void GraphicBomber::setTextureCNoWall1(RectangleShape ** rectangle,int i , int j)
  		{
   			 rectangle[i][j].setTexture(&noWall1);
   		}
   		 void GraphicBomber::setTextureCNoWall2(RectangleShape ** rectangle,int i , int j)
  		{
   			 rectangle[i][j].setTexture(&noWall2);
   		}

   		void GraphicBomber::setBoard(Board &board)
	{
		for( int j=0 ; j<17 ; j++)
		{
			for( int i=0 ;i<17 ; i++)
					{
						if(board.game_board[i][j]=='n')
						{
							setTextureCNoWall1(rectangle ,i ,j );
						}
						if(board.game_board[i][j]=='N')
						{
							setTextureCNoWall2( rectangle , i , j);
						}
						if(board.game_board[i][j]=='e')
						{
							setTextureCExAbleWall( rectangle , i , j);
						}
						if(board.game_board[i][j]=='b')
						{
							setTextureCBrike( rectangle , i , j);
						}
					}
		}
	}
	 void GraphicBomber::setPositionR( RectangleShape **r,int x,int y,int i ,int j)
  {
    r[i][j].setPosition( x , y );
  }
  void GraphicBomber::setPositionC( CircleShape &c,int x,int y)
  {  c.setPosition( x , y );
  }
   
    void GraphicBomber::rectSetsize(int i ,int j,int x,int y)
  {
        rectangle[i][j].setSize(sf::Vector2f(x, y));
  }
  void GraphicBomber::circleSetSize( CircleShape &c, int r)
  {
     c.setRadius(r);
  }
  void GraphicBomber::showGift(Gift ** gift ,Board &board)
  {
  	  int n = 0 ;
  	  while(n<10){
  			if(board.game_board[gift[n]->getX()][gift[n]->getY()]=='n'&& gift[n]->isSeen == false)
  			{
				
  				 
  			     if(gift[n]->getType() == 'B')
					
					{
					    circleSetSize( bombC , 10);
						setPositionC(bombC ,gift[n]->getX()*42,gift[n]->getY()*42);
						drawCir(bombC);
					
					}
   
	  			  else
					
					{
						
					    circleSetSize( bombC , 25);
						setPositionC(bombC ,gift[n]->getX()*42,gift[n]->getY()*42);
						drawCir(bombC);
					
					}
					
  	      }
  	     
  	       n++;}

  }
	void GraphicBomber::show(Board &board ,Player &player1 ,Bomb &bomb1 ,Player &player2 ,Bomb &bomb2 ,Gift ** gift)
	{
		CircleShape circle2;
		load();
		clearScreen();
		setBoard(board);
		for (int i = 0; i < 17; i++)
		{
			for (int j = 0; j < 17; j++)
			{
				rectSetsize( i, j ,42,42);
				setPositionC(circle ,player1.getX()*42,player1.getY()*42);
				setPositionC(circle2 ,player2.getX()*42,player2.getY()*42);
				setPositionR(rectangle ,i*42,j*42 , i, j);
				drawRect(rectangle , i, j);
				
			}
			if(bomb1.bombLocated)
			{
				circleSetSize( bombC , 10);
				setPositionC(bombC ,bomb1.getX()*42,bomb1.getY()*42);
		         drawCir(bombC);
			}
			if(bomb2.bombLocated)
			{
				circleSetSize( bombC , 10);
				setPositionC(bombC ,bomb2.getX()*42,bomb2.getY()*42);
		         drawCir(bombC);
			}
		}
		showGift(gift ,board);
		circleSetSize( circle , 21);
		circleSetSize( circle2 , 21);
		drawCir(circle);
		drawCir(circle2);
		display();
	}

