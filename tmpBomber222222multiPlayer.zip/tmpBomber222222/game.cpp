#include "game.h"
#include  <iostream>
#include <string>
#include <fstream>
#include <ctime>
using namespace std;
Game::Game()
{
// srand(time(0));
}
void Game::Board_Cout( Board &board)
{
	for (int i = 0; i < 17; i++)
	{
		for (int j = 0; j < 17; j++)
		{
			cout<<board.game_board[i][j]<<" ";
		}
		cout<<endl;
	}
}
Key* Game::setKeys1(GraphicBomber &graphic ,Key &key ,Player &player)
{
	key.right=graphic.rightKeyPressed();
	key.left=graphic.leftKeyPressed();
	key.up=graphic.upKeyPressed();
	key.down = graphic.downKeyPressed();
	if(key.right || key.left || key.up || key.down)
	{
	cout<<"x="<<player.getX()<<endl;
    cout<<"y="<<player.getY()<<endl;}
    
	return &key;
}
Key* Game::setKeys2(GraphicBomber &graphic ,Key &key ,Player &player)
{
	key.right=graphic.dKeyPressed();
	key.left=graphic.aKeyPressed();
	key.up=graphic.wKeyPressed();
	key.down = graphic.sKeyPressed();
	if(key.right || key.left || key.up || key.down)
	{
	cout<<"x="<<player.getX()<<endl;
    cout<<"y="<<player.getY()<<endl;}
    
	return &key;
}
Gift ** Game::locateGift( Board &board)
{
	bool b;
	int t1 ,t2;
	bool**giftLoc;
		giftLoc = new bool *[17];
	for (int i = 0; i <17; i++)
	{
		
		giftLoc[i] = new bool [17];
	}
	for( int i = 0 ; i < 17 ;i++)
		for( int j = 0 ; j < 17 ;j++)
			giftLoc[i][j]=false;
	Gift ** tmp = new Gift* [10];
   srand(time(0));
	   for ( int  i = 0 ; i < 10 ; i++ )
	   {
	   	b = rand()%2;
        if(b)
        {
        	
        	tmp[i] = new LifePlus();
        	cout<<"l"<<endl;
        }
        else
        {
        
        	tmp[i] = new BombPlus();
        	cout<<"b"<<endl;
        }
	 
	do{
		
		t1=rand()%17;
		t2=rand()%17;
		tmp[i]->setX(rand()%17);
		tmp[i]->setY(rand()%17);
		
     

  }	while(board.game_board[tmp[i]->getX()][tmp[i]->getY()]!='e'  ||giftLoc[tmp[i]->getX()][tmp[i]->getY()]==1);
cout<<tmp[i]->getX()<<" "<<tmp[i]->getY()<<endl;
giftLoc[tmp[i]->getX()][tmp[i]->getY()]=1;
}
    return tmp;
}
void Game::giftApply(Player &player ,Gift ** gift , Bomb &bomb )
{
	cout<<"lP:"<<player.getLife()<<endl;
	cout<<"bP:"<<bomb.getDownRang()<<endl;
	for(int i = 0 ;i<10 ;i++)
	{
		if(player.getX() == gift[i]->getX() && player.getY() == gift[i]->getY() && gift[i]->isSeen == false)
			{
				gift[i]->rangAdder(bomb);
				gift[i]->addLife(player);
				gift[i]->isSeen = true;
					
  	    }
		
    }
}
bool Game::isAlive(Player &player)
{
	if(player.getLife() <= 0)
	    return false;
	else
	{
		cout<<player.getLife()<<endl;
	    return true;}
	
}
void Game::run(GraphicBomber &graphic, Key &key1, Key &key2 , Player &player1 ,Player &player2 , Board &board ,Bomb &bomb1 ,Bomb &bomb2 ,Gift**gift)
{
	
	
	player1.moveControl(*(setKeys1(graphic ,key1 ,player1)),board);
    player2.moveControl(*(setKeys2(graphic ,key2 ,player2)),board);
    bomb1.bombIsLocated(key1 ,player1,graphic.bKeyPressed());
    bomb1.boardUpdater(board , player1 , player2 );
    bomb2.bombIsLocated(key2,player2,graphic.mKeyPressed());
    bomb2.boardUpdater(board , player1 , player2 );
    giftApply(player1 , gift ,bomb1);
    giftApply(player2 , gift ,bomb2);
  
    
}

